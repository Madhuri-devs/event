import { Component } from '@angular/core';

@Component({
  selector: 'app-abouts-us',
  templateUrl: './abouts-us.component.html',
  styleUrls: ['./abouts-us.component.scss']
})
export class AboutsUsComponent {

}
